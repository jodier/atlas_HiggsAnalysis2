#ifndef HSG3TrigLeptonSFTool_H__
#define HSG3TrigLeptonSFTool_H__

#include <iostream>
#include "TrigMuonEfficiency/LeptonTriggerSF.h"

class HSG3TrigLeptonSFTool {

 public:
  
  HSG3TrigLeptonSFTool(std::string dir, double intLumiJ, double intLumiK, double intLumiL, double intLumiM);
  ~HSG3TrigLeptonSFTool();

  double MuEff_CB_HSG3(std::string period, bool isData, TLorentzVector muon) const;
  std::pair<double, double> MuEffErr_CB_HSG3(std::string period, bool isData, TLorentzVector muon) const;

 private:

  LeptonTriggerSF * my_leptonTriggerSF;

  double m_intLumiJ;
  double m_intLumiK;
  double m_intLumiL;
  double m_intLumiM;

};

#endif 
