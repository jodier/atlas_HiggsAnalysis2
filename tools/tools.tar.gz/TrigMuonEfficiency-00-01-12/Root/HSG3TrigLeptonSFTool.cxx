#include "TrigMuonEfficiency/HSG3TrigLeptonSFTool.h"

using namespace TrigMuonEff;

HSG3TrigLeptonSFTool::HSG3TrigLeptonSFTool(std::string dir,
					   double intLumiJ = 226.391, 
					   double intLumiK = 590.36, 
					   double intLumiL = 1404.79, 
					   double intLumiM = 1026.94){ 
  std::cout << "HSGTrigLeptonSFTool: Initializing" << std::endl;
  my_leptonTriggerSF = new LeptonTriggerSF(dir);
  m_intLumiJ = intLumiJ;
  m_intLumiK = intLumiK;
  m_intLumiL = intLumiL;
  m_intLumiM = intLumiM;
}

HSG3TrigLeptonSFTool::~HSG3TrigLeptonSFTool(){}

double HSG3TrigLeptonSFTool::MuEff_CB_HSG3(std::string period, bool isData, TLorentzVector muon) const{

  double efficiency = 0;

  /*  if( period == "per2011B2_I" ) {
    efficiency = my_leptonTriggerSF->MuEff_CB( per2011B2_I, isData, muon);
  }else if( period == "per2011J_M" ) {
    efficiency = my_leptonTriggerSF->MuEff_CB( per2011J_M, isData, muon);
  }else if( period == "per2011J" ) {
    efficiency = my_leptonTriggerSF->MuEff_CB( per2011J, isData, muon);
  }else if( period == "per2011K" ) {
    efficiency = my_leptonTriggerSF->MuEff_CB( per2011K, isData, muon);
  }else if( period == "per2011J_K" ) {
    double eff1 = my_leptonTriggerSF->MuEff_CB( per2011J, isData, muon);
    double eff2 = my_leptonTriggerSF->MuEff_CB( per2011K, isData, muon);
    efficiency = (m_intLumiJ*eff1 + m_intLumiK*eff2)/(m_intLumiJ + m_intLumiK); 
  }else if( period == "per2011L_M" ) {
    double eff1 = my_leptonTriggerSF->MuEff_CB( per2011L, isData, muon);
    double eff2 = my_leptonTriggerSF->MuEff_CB( per2011M, isData, muon);
    efficiency = (m_intLumiL*eff1 + m_intLumiM*eff2)/(m_intLumiL + m_intLumiM); 
    }*/

  return efficiency;

}

std::pair<double, double> HSG3TrigLeptonSFTool::MuEffErr_CB_HSG3(std::string period, bool isData, TLorentzVector muon) const{

  double efficiency = 0;
  double error = 0;

  if( period == "per2011B2_I" ) {
    efficiency = (my_leptonTriggerSF->MuEff( per2011B_I, isData, muon, combined)).first;
    error = (my_leptonTriggerSF->MuEff( per2011B_I, isData, muon, combined)).second;
  }else if( period == "per2011J_M" ) {
    efficiency = (my_leptonTriggerSF->MuEff( per2011J_M, isData, muon, combined)).first;
    error = (my_leptonTriggerSF->MuEff( per2011J_M, isData, muon, combined)).second;
  }else if( period == "per2011J" ) {
    efficiency = (my_leptonTriggerSF->MuEff( per2011J, isData, muon, combined)).first;
    error = (my_leptonTriggerSF->MuEff( per2011J, isData, muon, combined)).second;
  }else if( period == "per2011K" ) {
    efficiency = (my_leptonTriggerSF->MuEff( per2011K, isData, muon, combined)).first;
    error = (my_leptonTriggerSF->MuEff( per2011K, isData, muon, combined)).second;
  }else if( period == "per2011J_K" ) {
    efficiency = (my_leptonTriggerSF->MuEff( per2011J_K, isData, muon, combined)).first;
    error = (my_leptonTriggerSF->MuEff( per2011J_K, isData, muon, combined)).second;
  }else if( period == "per2011L_M" ) {
    efficiency = (my_leptonTriggerSF->MuEff( per2011L_M, isData, muon, combined)).first;
    error = (my_leptonTriggerSF->MuEff( per2011L_M, isData, muon, combined)).second;
  }

  return std::pair<double, double> ( efficiency, error );

}
