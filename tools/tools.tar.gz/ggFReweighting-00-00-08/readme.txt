ggFReweiting : reweight normalized Higgs Pt to NNLL+NLO by HqT2.0

Available generators: PowHeg, McAtNlo, PowHegMSSM
Weights for MC11 and MC10 are available
Statistical error: generator statistical error
Pdf Uncertianty  : MSTW2008 NNLO 90%C.L eigenvectors, Sqrt{ Sum (x_i-x_i+1)^2}/2 summing over pairs, e.g. (x1-x2)^2 + (x3-x4)^2... {the numbers being pdf set numbers}
Scale uncertainty: max deviation{x_i-x_j}/2
Available options are : "Mean", "PdfsetX" where X={1,40}, and "ScaleX" where X={1,13}

The mass and pt unit is "GeV"

Please also see the example.C for usage

###########
Compiling #
###########
Generating .so
$ root -l ggFReweighting.cxx++

Depending on the version of ROOT (e.g. 5.26/00e), it may return "Error: Symbol null is not defined in current scope  :0:".  This doesn't seem to affect operation and does not occur on newer verions.  

If you aren't using ROOT to compile the class, you might have issues because of the ClassDef in the header and ClassImp in the sources file.  Remove these if they cause problems.

#######################
Available Mass Points #
#######################

The package will print out information about itself by calling the printInfo() function:
MC11:

	Available generators  : 
	McAtNlo
	Available mass points : [  110  115  120  125  130  135  140  145  150  155  160  165  170  175  180  185  190  195  200  220  240  260  280  300  320  340  360  380  400  420  440  460  480  500  520  540  560  580  600 ] GeV

	PowHeg
	Available mass points : [  100  105  110  115  120  125  130  135  140  145  150  155  160  165  170  175  180  185  190  195  200  210  220  240  260  280  300  320  340  360  380  400  420  440  460  480  500  520  540  560  580  600  650  700  750  800  850  900 ] GeV

	PowHegMSSM
	Available mass points : [   90  100  110  120  130  140  150  170  200  250  300  350  400  450  500  600 ] GeV
	----
	Available error points (scale and pdf): [ 120, 130, 160, 200, 300, 400, 500, 600, 700, 800, 900 ] GeV

MC10: 
	Available generators  :	     
	McAtNlo
	Available mass points : [  110  115  120  125  130  135  140  145  150  155  160  165  170  175  180  185  190  195  200  220  240  260  280  300 ] GeV

	PowHeg
	Available mass points : [  100, 105, 110  115  120  125  130  135  140  145  150  155  160  165  170  175  180  185  190  195  200  210  220  240  260  280  300  320  340  360  380  400  420  440  460  480  500  520  540  560  580  600 ] GeV
	PowHegMSSM

	Available mass points : [   90  100  110  120  130  140  150  170  200  250  300  350  400  450  500  600 ] GeV
	----
	Available error points (scale and pdf): [ 120, 130, 160, 200, 300, 400, 500, 600 ] GeV

##################
QCD Scale Points #
##################

QCD Scaling numbers correspond to the following, relative to m_h: 

#	mu_r	mu_f	Q
0	1	1	.5
1	1	1	1
2	.5	.5	.25
3	.5	.5	.5
4	.5	.5	1
5	.5	1	.25
6	.5	1	.5
7	.5	1	1
8	1	.5	.5
9	1	.5	1
10	1	2	.5
11	1	2	1
12	2	1	1
13	2	2	1