void example()
{
  gROOT->ProcessLine(".L ggFReweighting.cxx+");
  
  //// Initialize ggFReweighting
  //// The first option is the generator
  //// The second is the Higgs mass in GeV 
  //// The third option by default is "Mean". It can be "Pdfset[1..41]" or "Scale[1-13]"
  //// The fourth, the path of the input root file, which by default is "./"
  //// The last picks either mc10 or mc11 (defaults to mc11)
  ggFReweighting reweight("PowHegMSSM", 500, "Mean", "./", "mc11");

  //// take a look available generator and higgsMass points
  reweight.printInfo();
  
  //// higgsPt is in GeV
  double higgsPt = 23.2;

  pair<double, double> result = reweight.getWeightAndStatError(higgsPt);
  
  cout << " Option = " << reweight.option() << endl;
  cout << " Higgs Pt = " << higgsPt << " GeV" << endl;
  cout << " weight +/- error (M_H = " << reweight.higgsMass() << " GeV) " << endl 
       << "                  = " << result.first << " +/- " << result.second << endl;
     
  int i;
  for(i = 0; i < 10; i++)
    {
      cout << " Higgs Pt = " << higgsPt << " GeV (M_H = " << i*10 + 110 << " GeV) : " << endl;
      reweight.initialize("PowHeg", i*10 + 110);
      cout << " Option = " << reweight.option() << endl;
      cout << " PowHeg weight " << reweight.getWeight(higgsPt);

      reweight.initialize("McAtNlo", i*10 + 110);
      cout << " McAtNlo weight " << reweight.getWeight(higgsPt) ;
      
      cout << endl;
    }
}
  
//// Example to get higgs pt from WZD3PD
//// for the Pythia and PowHeg, Higgs pt can be retrieved by PdgID
//// for McAtNlo, Higgs pt can be retreived by summed all the decay particles
/*template class <Type> 
double getHiggsPt(string generator, Type _tMC)
{ 
  int i;                        
  double higgsPt = -999;
  vector<int> parentID;
  TLorentzVector tempV4;
  TLorentzVector higgsV4;
  if(generator == "Pythia" || generator == "PowHeg")
    {
      for(i = 0; i < _tMC->mc_n; i++)
        {
          if(TMath::Abs(_tMC->mc_pdgId->at(i)) == 25)
            {
              higgsPt = _tMC->mc_pt->at(i)/1000.0;
            }
        }
    }
  else if(generator == "McAtNlo")
    {
      for(i = 0; i < _tMC->mc_n; i++)
        {
          if(TMath::Abs(_tMC->mc_pdgId->at(i)) >= 11 && TMath::Abs(_tMC->mc_pdgId->at(i)) <= 16)
            {
              parentID = _tMC->mc_parent_index->at(i);
              if(parentID.size() > 0 && parentID[0] < _tMC->mc_n && TMath::Abs(_tMC->mc_pdgId->at(parentID[0])) == 24)
                {
                  tempV4.SetPtEtaPhiM(_tMC->mc_pt->at(i)/1000.0,
                                      _tMC->mc_eta->at(i),
                                      _tMC->mc_phi->at(i),
                                      _tMC->mc_m->at(i)/1000.0);
                  higgsV4 = higgsV4 + tempV4;
                }
            }
        }
      higgsPt = higgsV4.Pt();
    }

  if(higgsPt == -999)
    {
      cout << generator << " is not available, Please check again!" << endl;
    }
  return higgsPt;
  }*/
