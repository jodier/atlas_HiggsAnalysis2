#include "HiggsZZ4lUtils/BkgCrossSection.h"
#include <iostream>
#include <string>


double GetBkgCrossSection(int RunNumber,bool PrintSummary){
  
  double crossSection=-1.0;
  std::string name="";
  
  if (RunNumber==107650){
    name="Alpgen+Jimmy Zee + 0	partons ";
    crossSection=827375.;
  }else if (RunNumber==107651){
    name="Alpgen+Jimmy Zee + 1	partons ";
    crossSection=166625.;
  }else if (RunNumber==107652){
    name="Alpgen+Jimmy Zee + 2	partons ";
    crossSection=50375.;
  }else if (RunNumber==107653){
    name="Alpgen+Jimmy Zee + 3	partons ";
    crossSection=14000.;
  }else if (RunNumber==107654){
    name="Alpgen+Jimmy Zee + 4	partons ";
    crossSection=3375.;
  }else if (RunNumber==107655){
    name="Alpgen+Jimmy Zee + 5	partons ";
    crossSection=1000.;
  }else if (RunNumber==107660){
    name="Alpgen+Jimmy Zmumu + 0	partons ";
    crossSection=822125;
  }else if (RunNumber==107661){
    name="Alpgen+Jimmy Zmumu + 1	partons ";
    crossSection=166000.;
  }else if (RunNumber==107662){
    name="Alpgen+Jimmy Zmumu + 2	 partons ";
    crossSection=49500.;
  }else if (RunNumber==107663){
    name="Alpgen+Jimmy Zmumu + 3	partons "; 
    crossSection=13875.;
  }else if (RunNumber==107664){
    name="Alpgen+Jimmy Zmumu + 4	partons ";
    crossSection=3500.;
  }else if (RunNumber==107665){
    name="Alpgen+Jimmy Zmumu + 5	partons ";
    crossSection=1000.;
  }else if (RunNumber==107670){
    name="Alpgen+Jimmy Ztautau + 0	partons ";
    crossSection=828125.;
  }else if (RunNumber==107671){
    name="Alpgen+Jimmy Ztautau + 1	partons ";
    crossSection=167375.;
  }else if (RunNumber==107672){
    name="Alpgen+Jimmy Ztautau + 2	partons ";
    crossSection=50375.;
  }else if (RunNumber==107673){
    name="Alpgen+Jimmy Ztautau + 3	partons ";
    crossSection=13750;
  }else if (RunNumber==107674){
    name="Alpgen+Jimmy Ztautau + 4	partons ";
    crossSection=3500.;
  }else if (RunNumber==107675){
    name="Alpgen+Jimmy Ztautau + 5	partons ";
    crossSection=1000.;
  }else if (RunNumber==116960){
    name="Zbb, Z->ee (ll > 30 !GeV) + 0 parton [m_4l 60/12 !GeV] ";
    crossSection=20.701*1.4;
  }else if (RunNumber==116961){
    name="Zbb, Z->ee (ll > 30 !GeV) + 1 parton [m_4l 60/12 !GeV] ";
    crossSection=18.8029*1.4;
  }else if (RunNumber==116962){
    name="Zbb, Z->ee (ll > 30 !GeV) + 2 parton [m_4l 60/12 !GeV] ";
    crossSection=10.505*1.4;
  }else if (RunNumber==116963){
    name="Zbb, Z->ee (ll > 30 !GeV) + 3 parton [m_4l 60/12 !GeV] ";
    crossSection=7.30463*1.4;
  }else if (RunNumber==116965){
    name="Zbb, Z->mumu (ll > 30 !GeV) + 0 parton [m_4l 60/12 !GeV] ";
    crossSection=21.516*1.4;
  }else if (RunNumber==116966){ 
    name="Zbb, Z->mumu (ll > 30 !GeV) + 1 parton [m_4l 60/12 !GeV] ";
    crossSection=19.6674*1.4;
  }else if (RunNumber==116967){
    name="Zbb, Z->mumu (ll > 30 !GeV) + 2 parton [m_4l 60/12 !GeV] ";
    crossSection=10.516*1.4;
  }else if (RunNumber==116968){
    name="Zbb, Z->mumu (ll > 30 !GeV) + 3 parton [m_4l 60/12 !GeV] ";
    crossSection=7.93834*1.4;
  }else if (RunNumber==116950){
    name="Zbb, Z->ee (ll > 30 !GeV) + 0 parton 3l filter, veto on m_4l 60/12 !GeV ";
    crossSection=756.32*1.4;
  }else if (RunNumber==116951){
    name="Zbb, Z->ee (ll > 30 !GeV) + 1 parton 3l filter, veto on m_4l 60/12 !GeV ";
    crossSection=432.25*1.4;
  }else if (RunNumber==116952){
    name="Zbb, Z->ee (ll > 30 !GeV) + 2 parton 3l filter, veto on m_4l 60/12 !GeV ";
    crossSection=176*1.4;
  }else if (RunNumber==116953){ 
    name="Zbb, Z->ee (ll > 30 !GeV) + 3 parton 3l filter, veto on m_4l 60/12 !GeV ";
    crossSection=96.75*1.4;
  }else if (RunNumber==116955){ 
    name="Zbb, Z->mumu (ll > 30 !GeV) + 0 parton 3l filter, veto on m_4l 60/12 !GeV ";
    crossSection=730.24*1.4;
  }else if (RunNumber==116956){ 
    name="Zbb, Z->mumu (ll > 30 !GeV) + 1 parton 3l filter, veto on m_4l 60/12 !GeV ";
    crossSection=432.25*1.4;
  }else if (RunNumber==116957){ 
    name="Zbb, Z->mumu (ll > 30 !GeV) + 2 parton 3l filter, veto on m_4l 60/12 !GeV ";
    crossSection=179.3*1.4;
  }else if (RunNumber==116958){ 
    name="Zbb, Z->mumu (ll > 30 !GeV) + 3 parton 3l filter, veto on m_4l 60/12 !GeV ";
    crossSection=92.3962*1.4;
  }else if (RunNumber==128130){ 
    name="AlpgenJimmyLowMassDYeebbNp0_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128131){ 
    name="AlpgenJimmyLowMassDYeebbNp1_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128132){ 
    name="AlpgenJimmyLowMassDYeebbNp2_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128133){ 
    name="AlpgenJimmyLowMassDYeebbNp3_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128135){ 
    name="AlpgenJimmyLowMassDYmumubbNp0_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128136){ 
    name="AlpgenJimmyLowMassDYmumubbNp1_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128137){ 
    name="AlpgenJimmyLowMassDYmumubbNp2_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128138){ 
    name="AlpgenJimmyLowMassDYmumubbNp3_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128140){ 
    name="AlpgenJimmyLowMassDYtautaubbNp0_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128141){ 
    name="AlpgenJimmyLowMassDYtautaubbNp1_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128142){ 
    name="AlpgenJimmyLowMassDYtautaubbNp2_nofilter ";
    crossSection=-1;
  }else if (RunNumber==128143){ 
    name="AlpgenJimmyLowMassDYtautaubbNp3_nofilter ";
    crossSection=-1;
  }else if (RunNumber==105200){ 
    name="ttbar (at least 1lepton filter) ";
    crossSection=91550.6;
  }else if (RunNumber==109345){ 
    name="ttbar (with Mll > 60 !GeV filter) ";
    crossSection=12707.2;
  }else if (RunNumber==109346){ 
    name="ttbar (with Mll > 60 !GeV filter and Mll > 12 !GeV) ";
    crossSection=515.2;
  }else if (RunNumber==109292){ 
    name="ZZ->4l 3LepFilter ";
    crossSection=91.54;
  }else if (RunNumber==126399){ 
    name="PowHegBoxZZeemm_Pythia_mll025_m4l40 ";
    crossSection=-1;
  }else if (RunNumber==126400){ 
    name="PowHegBoxZZeeee_Pythia_mll025_m4l40 ";
    crossSection=-1;
  }else if (RunNumber==126401){ 
    name="PowHegBoxZmmmm_Pythia_mll025_m4l40 ";
    crossSection=-1;
  }else if (RunNumber==128813){ 
    name="SherpaZZllll ";
    crossSection=-1;
  }else if (RunNumber==116600){ 
    name="gg2ZZ_JIMMY_ZZ4lep (gg2ZZv2.0) ";
    crossSection=-1;
  }else if (RunNumber==128593){ 
    name="PythiaZZall_EF_15_5 ";
    crossSection=-1;
  }
  
  if (PrintSummary){
    if (crossSection!=-1){
      std::cout <<"-----------------------------------------------------------"<<std::endl;
      std::cout <<" Cross section for background process " << std::endl;
      std::cout <<"-----------------------------------------------------------"<<std::endl;
      std::cout <<"-----------------------------------------------------------"<<std::endl;
      std::cout <<"               Run Number                      = "<< RunNumber << std::endl;
      std::cout <<"               process                         = "<< name << std::endl;
      std::cout <<"               Cross section x Branching Ratio = "<< crossSection <<" fb^-1 "<< std::endl;
      std::cout <<"-----------------------------------------------------------"<<std::endl;
    }else{
      std::cout <<"-----------------------------------------------------------"<<std::endl;
      std::cout <<" Cross section for background process " << std::endl;
      std::cout <<"-----------------------------------------------------------"<<std::endl;
      std::cout <<"-----------------------------------------------------------"<<std::endl;
      std::cout <<"               Run Number                      = "<< RunNumber << std::endl;
      std::cout <<"               process                         = "<< name << std::endl;
      std::cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
      std::cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
      std::cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
      std::cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
      std::cout <<"                    NO Cross section !!!  " << std::endl;
      std::cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
      std::cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
      std::cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
      std::cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
    }
  }
  return crossSection;
  
}

