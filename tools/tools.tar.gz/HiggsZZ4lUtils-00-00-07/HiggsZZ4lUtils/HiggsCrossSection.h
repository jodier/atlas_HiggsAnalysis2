#ifndef HIGGSCROSSSECTION_H
#define HIGGSCROSSSECTION_H

double higgsxsecGGF(double mass);
double higgsxsecVBF(double mass);
double higgsxsecWH(double mass);
double higgsxsecZH(double mass);
#endif
