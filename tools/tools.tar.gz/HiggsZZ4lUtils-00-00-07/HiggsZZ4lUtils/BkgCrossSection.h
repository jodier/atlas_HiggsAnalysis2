#ifndef BKGCROSSSECTION_H
#define BKGCROSSSECTION_H

double GetBkgCrossSection(int RunNumber,bool PrintSummary);

#endif
